@echo off
chcp 65001 >nul
title Rihlati - رحلتي لإدارة الفواتير والمشتريات
set "APP_DIR=%~dp0"
if exist "%APP_DIR%www\index.html" (
    set "TARGET_HTML=%APP_DIR%www\index.html"
) else (
    set "TARGET_HTML=%APP_DIR%app\src\main\assets\index.html"
)

:: إذا كان ملف Rihlati.exe موجوداً، شغّله مباشرة
if exist "%APP_DIR%Rihlati.exe" (
    start "" "%APP_DIR%Rihlati.exe"
    exit /b 0
)

:: تجميع Rihlati.exe تلقائياً في ثانية واحدة باستخدام مترجم ويندوز المدمج إن توفر
set "CSC=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if exist "%CSC%" if exist "%APP_DIR%windows-app\RihlatiDesktop.cs" (
    if not exist "%APP_DIR%www" mkdir "%APP_DIR%www"
    xcopy /Y /E /Q "%APP_DIR%app\src\main\assets\*" "%APP_DIR%www\" >nul 2>&1
    "%CSC%" /nologo /target:winexe /out:"%APP_DIR%Rihlati.exe" /win32icon:"%APP_DIR%windows-app\app.ico" /r:System.Windows.Forms.dll "%APP_DIR%windows-app\RihlatiDesktop.cs" >nul 2>&1
    if exist "%APP_DIR%Rihlati.exe" (
        start "" "%APP_DIR%Rihlati.exe"
        exit /b 0
    )
)

:: البديل المباشر: فتح التطبيق في نافذة مستقلة مسرّعة بالعتاد (GPU App Mode)
set "PROFILE_DIR=%APP_DIR%RihlatiProfile"
for %%P in (
    "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
    "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
    "%ProgramFiles%\Google\Chrome\Application\chrome.exe"
    "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
) do (
    if exist %%~P (
        start "" %%P --app="file:///%TARGET_HTML:\=/%" --user-data-dir="%PROFILE_DIR%" --window-size=1200,860 --enable-gpu-rasterization --enable-zero-copy --disable-background-timer-throttling
        exit /b 0
    )
)
start "" "%TARGET_HTML%"
