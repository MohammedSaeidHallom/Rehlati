using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace RihlatiDesktop
{
    static class Program
    {
        private static HttpListener listener;
        private static string baseDir;
        private static string wwwDir;
        private static string dataFilePath;

        [STAThread]
        static void Main()
        {
            baseDir = AppDomain.CurrentDomain.BaseDirectory;
            wwwDir = Path.Combine(baseDir, "www");
            if (!Directory.Exists(wwwDir))
            {
                string alt = Path.Combine(baseDir, "..", "app", "src", "main", "assets");
                if (Directory.Exists(alt)) wwwDir = Path.GetFullPath(alt);
            }
            dataFilePath = Path.Combine(baseDir, "rehlati_data_backup.json");

            int port = GetFreePort();
            string url = "http://127.0.0.1:" + port + "/index.html";

            Thread serverThread = new Thread(() => StartServer(port));
            serverThread.IsBackground = true;
            serverThread.Start();

            Process browserProc = LaunchAppWindow(url);
            if (browserProc != null)
            {
                try { browserProc.WaitForExit(); } catch { }
                // Keep server alive for 10 minutes or until idle if browser handed off to existing process
                Thread.Sleep(3000);
            }
            else
            {
                Process.Start(url);
                Application.Run(new HiddenTrayContext(url));
            }
        }

        static int GetFreePort()
        {
            TcpListener l = new TcpListener(IPAddress.Loopback, 0);
            l.Start();
            int port = ((IPEndPoint)l.LocalEndpoint).Port;
            l.Stop();
            return port;
        }

        static Process LaunchAppWindow(string url)
        {
            string userDataDir = Path.Combine(baseDir, "RihlatiProfile");
            string gpuFlags = "--app=" + url + " --user-data-dir=\"" + userDataDir + "\" --window-size=1200,860 --enable-gpu-rasterization --enable-zero-copy --disable-background-timer-throttling --disable-renderer-backgrounding --no-first-run --no-default-browser-check";

            string[] candidates = new string[] {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft\Edge\Application\msedge.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Microsoft\Edge\Application\msedge.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Google\Chrome\Application\chrome.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Google\Chrome\Application\chrome.exe")
            };

            foreach (string exe in candidates)
            {
                if (File.Exists(exe))
                {
                    try
                    {
                        ProcessStartInfo psi = new ProcessStartInfo(exe, gpuFlags);
                        psi.UseShellExecute = false;
                        return Process.Start(psi);
                    }
                    catch { }
                }
            }
            return null;
        }

        static void StartServer(int port)
        {
            try
            {
                listener = new HttpListener();
                listener.Prefixes.Add("http://127.0.0.1:" + port + "/");
                listener.Start();
                while (listener.IsListening)
                {
                    HttpListenerContext ctx = listener.GetContext();
                    ThreadPool.QueueUserWorkItem(_ => HandleRequest(ctx));
                }
            }
            catch { }
        }

        static void HandleRequest(HttpListenerContext ctx)
        {
            try
            {
                string path = ctx.Request.Url.AbsolutePath.TrimStart('/');
                if (path == "api/save" && ctx.Request.HttpMethod == "POST")
                {
                    using (StreamReader sr = new StreamReader(ctx.Request.InputStream, Encoding.UTF8))
                    {
                        string body = sr.ReadToEnd();
                        if (!string.IsNullOrEmpty(body))
                        {
                            File.WriteAllText(dataFilePath, body, Encoding.UTF8);
                        }
                    }
                    byte[] ok = Encoding.UTF8.GetBytes("{\"ok\":true}");
                    ctx.Response.ContentType = "application/json";
                    ctx.Response.OutputStream.Write(ok, 0, ok.Length);
                    ctx.Response.Close();
                    return;
                }

                if (string.IsNullOrEmpty(path)) path = "index.html";
                string filePath = Path.Combine(wwwDir, path.Replace('/', Path.DirectorySeparatorChar));
                if (!File.Exists(filePath))
                {
                    ctx.Response.StatusCode = 404;
                    ctx.Response.Close();
                    return;
                }

                byte[] content = File.ReadAllBytes(filePath);
                if (path == "index.html" && File.Exists(dataFilePath))
                {
                    string savedJson = File.ReadAllText(dataFilePath, Encoding.UTF8);
                    string htmlStr = Encoding.UTF8.GetString(content);
                    string inject = "<script>window.__INITIAL_SERVER_STATE__ = " + savedJson + ";</script></head>";
                    htmlStr = htmlStr.Replace("</head>", inject);
                    content = Encoding.UTF8.GetBytes(htmlStr);
                }

                ctx.Response.ContentType = GetMimeType(filePath);
                ctx.Response.ContentLength64 = content.Length;
                ctx.Response.Headers["Cache-Control"] = "no-cache";
                ctx.Response.OutputStream.Write(content, 0, content.Length);
                ctx.Response.Close();
            }
            catch
            {
                try { ctx.Response.Close(); } catch { }
            }
        }

        static string GetMimeType(string file)
        {
            string ext = Path.GetExtension(file).ToLowerInvariant();
            if (ext == ".html") return "text/html; charset=utf-8";
            if (ext == ".css") return "text/css; charset=utf-8";
            if (ext == ".js") return "application/javascript; charset=utf-8";
            if (ext == ".json") return "application/json; charset=utf-8";
            if (ext == ".png") return "image/png";
            if (ext == ".ico") return "image/x-icon";
            return "application/octet-stream";
        }
    }

    class HiddenTrayContext : ApplicationContext
    {
        public HiddenTrayContext(string url) { }
    }
}
