package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import com.example.ui.theme.MyApplicationTheme
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    var webViewInstance: WebView? = null

    private val fileChooserLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            fileChooserCallback?.onReceiveValue(arrayOf(uri))
        } else {
            fileChooserCallback?.onReceiveValue(null)
        }
        fileChooserCallback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webViewInstance?.evaluateJavascript(
                    """
                    (function() {
                        if (typeof window.handleAndroidBack === 'function') {
                            return window.handleAndroidBack();
                        }
                        return false;
                    })()
                    """.trimIndent()
                ) { result ->
                    if (result != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })

        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    WebViewScreen(modifier = Modifier.padding(innerPadding), activity = this@MainActivity)
                }
            }
        }
    }

    fun launchFileChooser(callback: ValueCallback<Array<Uri>>?) {
        fileChooserCallback = callback
        fileChooserLauncher.launch("*/*")
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(modifier: Modifier = Modifier, activity: MainActivity) {
    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { ctx ->
            WebView(ctx).apply {
                activity.webViewInstance = this
                overScrollMode = View.OVER_SCROLL_NEVER
                setLayerType(View.LAYER_TYPE_HARDWARE, null)
                isVerticalScrollBarEnabled = false
                isHorizontalScrollBarEnabled = false

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val url = request?.url.toString()
                        if (url.startsWith("https://wa.me/") || url.startsWith("whatsapp://") || url.startsWith("https://api.whatsapp.com/")) {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                ctx.startActivity(intent)
                                return true
                            } catch (e: Exception) {
                                return false
                            }
                        }
                        return super.shouldOverrideUrlLoading(view, request)
                    }
                }
                webChromeClient = object : WebChromeClient() {
                    override fun onShowFileChooser(
                        webView: WebView?,
                        filePathCallback: ValueCallback<Array<Uri>>?,
                        fileChooserParams: FileChooserParams?
                    ): Boolean {
                        activity.launchFileChooser(filePathCallback)
                        return true
                    }
                }
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    allowFileAccess = true
                    allowFileAccessFromFileURLs = true
                    allowUniversalAccessFromFileURLs = true
                    allowContentAccess = true
                    cacheMode = WebSettings.LOAD_DEFAULT
                    useWideViewPort = false
                    loadWithOverviewMode = false
                    textZoom = 100
                    setSupportZoom(false)
                    builtInZoomControls = false
                    displayZoomControls = false
                    loadsImagesAutomatically = true
                    layoutAlgorithm = WebSettings.LayoutAlgorithm.NORMAL
                    offscreenPreRaster = true
                }

                addJavascriptInterface(AndroidBridge(activity, this), "Android")

                loadUrl("file:///android_asset/index.html")
            }
        }
    )
}

class AndroidBridge(private val context: Context, private val webView: WebView) {
    private val prefs: SharedPreferences = context.getSharedPreferences("RehlatiPrefs", Context.MODE_PRIVATE)
    private var activePrintWebView: WebView? = null

    @JavascriptInterface
    fun saveData(jsonData: String) {
        prefs.edit().putString("app_data", jsonData).apply()
    }

    @JavascriptInterface
    fun loadData(): String? {
        return prefs.getString("app_data", null)
    }

    @JavascriptInterface
    fun printInvoice() {
        val activity = (context as? ComponentActivity) ?: return
        activity.runOnUiThread {
            try {
                val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                val printAdapter = webView.createPrintDocumentAdapter("فاتورة_حساب")
                val jobName = "Invoice_PDF"
                val printAttributes = PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()
                printManager?.print(jobName, printAdapter, printAttributes)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun exportExcel(base64Data: String, fileName: String) {
        val activity = (context as? ComponentActivity) ?: return
        activity.runOnUiThread {
            try {
                val pureBase64 = if (base64Data.contains(",")) {
                    base64Data.substringAfter(",")
                } else {
                    base64Data
                }
                val decodedBytes = Base64.decode(pureBase64, Base64.DEFAULT)
                val cachePath = File(context.cacheDir, "exports")
                if (!cachePath.exists()) {
                    cachePath.mkdirs()
                }
                val safeName = if (fileName.isBlank()) "سجل_الفواتير.xlsx" else if (fileName.endsWith(".xlsx")) fileName else "$fileName.xlsx"
                val file = File(cachePath, safeName)
                val stream = FileOutputStream(file)
                stream.write(decodedBytes)
                stream.flush()
                stream.close()

                val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                val mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, safeName)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val resInfoList = context.packageManager.queryIntentActivities(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
                for (resolveInfo in resInfoList) {
                    val packageName = resolveInfo.activityInfo.packageName
                    context.grantUriPermission(packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(intent, "تصدير ومشاركة ملف إكسل (Excel)").apply {
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun exportJson(jsonContent: String, fileName: String) {
        val activity = (context as? ComponentActivity) ?: return
        activity.runOnUiThread {
            try {
                val cachePath = File(context.cacheDir, "backups")
                if (!cachePath.exists()) {
                    cachePath.mkdirs()
                }
                val safeName = if (fileName.isBlank()) "نسخة_احتياطية_${System.currentTimeMillis()}.json" else if (fileName.endsWith(".json")) fileName else "$fileName.json"
                val file = File(cachePath, safeName)
                val stream = FileOutputStream(file)
                stream.write(jsonContent.toByteArray(Charsets.UTF_8))
                stream.flush()
                stream.close()

                val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                val mime = "application/json"
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, safeName)
                    putExtra(Intent.EXTRA_TEXT, "نسخة احتياطية من بيانات الفواتير والمواد والزبائن (JSON)")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val resInfoList = context.packageManager.queryIntentActivities(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
                for (resolveInfo in resInfoList) {
                    val packageName = resolveInfo.activityInfo.packageName
                    context.grantUriPermission(packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(intent, "حفظ ومشاركة النسخة الاحتياطية (JSON)").apply {
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun printDocument(title: String) {
        val activity = (context as? ComponentActivity) ?: return
        activity.runOnUiThread {
            try {
                val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                val docName = if (title.isBlank()) "تقرير_حساب" else title.replace(" ", "_")
                val printAdapter = webView.createPrintDocumentAdapter(docName)
                val printAttributes = PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()
                printManager?.print(docName, printAdapter, printAttributes)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun printHtmlContent(htmlContent: String, title: String) {
        val activity = (context as? ComponentActivity) ?: return
        activity.runOnUiThread {
            try {
                activePrintWebView?.let { oldView ->
                    try {
                        oldView.stopLoading()
                        (oldView.parent as? ViewGroup)?.removeView(oldView)
                        oldView.destroy()
                    } catch (ex: Exception) {
                        ex.printStackTrace()
                    }
                }
                activePrintWebView = null

                val cleanTitle = if (title.isBlank()) "تقرير" else title.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                val rootLayout = activity.window.decorView as? ViewGroup
                val pWebView = WebView(activity).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    visibility = View.INVISIBLE
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = true
                    settings.allowFileAccessFromFileURLs = true
                    settings.allowUniversalAccessFromFileURLs = true
                    settings.defaultTextEncodingName = "utf-8"
                    settings.loadsImagesAutomatically = true
                    settings.layoutAlgorithm = WebSettings.LayoutAlgorithm.NORMAL
                }

                rootLayout?.addView(pWebView)
                activePrintWebView = pWebView

                pWebView.webViewClient = object : WebViewClient() {
                    private var hasPrinted = false
                    override fun onPageFinished(view: WebView?, url: String?) {
                        if (hasPrinted) return
                        hasPrinted = true
                        view?.postDelayed({
                            try {
                                val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                                val printAdapter = view.createPrintDocumentAdapter(cleanTitle)
                                val printAttributes = PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build()
                                printManager?.print(cleanTitle, printAdapter, printAttributes)
                            } catch (ex: Exception) {
                                ex.printStackTrace()
                            }
                        }, 500)
                    }
                }

                pWebView.loadDataWithBaseURL("file:///android_asset/", htmlContent, "text/html", "utf-8", null)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun savePdf() {
        printInvoice()
    }

    @JavascriptInterface
    fun shareText(text: String) {
        val activity = (context as? ComponentActivity) ?: return
        activity.runOnUiThread {
            try {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val chooser = Intent.createChooser(intent, "مشاركة الفاتورة").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun shareWhatsApp(text: String, phone: String?) {
        val activity = (context as? ComponentActivity) ?: return
        activity.runOnUiThread {
            val rawPhone = phone?.trim() ?: ""
            val cleanDigits = rawPhone.replace(Regex("[^0-9]"), "")

            if (cleanDigits.isNotBlank()) {
                try {
                    val url = "https://api.whatsapp.com/send?phone=$cleanDigits&text=" + Uri.encode(text)
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        setPackage("com.whatsapp")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    return@runOnUiThread
                } catch (e: Exception) {
                    try {
                        val url = "https://api.whatsapp.com/send?phone=$cleanDigits&text=" + Uri.encode(text)
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                        return@runOnUiThread
                    } catch (e2: Exception) {
                        // fallback below
                    }
                }
            }

            try {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    `package` = "com.whatsapp"
                    putExtra(Intent.EXTRA_TEXT, text)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                try {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, text)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    val chooser = Intent.createChooser(intent, "مشاركة الفاتورة عبر واتساب").apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(chooser)
                } catch (ex: Exception) {
                    ex.printStackTrace()
                }
            }
        }
    }

    @JavascriptInterface
    fun shareImage(base64Image: String) {
        shareWhatsAppImage(base64Image, null)
    }

    @JavascriptInterface
    fun shareWhatsAppImage(base64Image: String, phone: String?) {
        val activity = (context as? ComponentActivity) ?: return
        activity.runOnUiThread {
            try {
                val pureBase64 = if (base64Image.contains(",")) {
                    base64Image.substringAfter(",")
                } else {
                    base64Image
                }
                val decodedBytes = Base64.decode(pureBase64, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)

                val cachePath = File(context.cacheDir, "images")
                if (!cachePath.exists()) {
                    cachePath.mkdirs()
                }
                val file = File(cachePath, "invoice_${System.currentTimeMillis()}.png")
                val stream = FileOutputStream(file)
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                stream.flush()
                stream.close()

                val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                val rawPhone = phone?.trim() ?: ""
                val cleanDigits = rawPhone.replace(Regex("[^0-9]"), "")

                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }

                // Grant URI permission explicitly to potential targets
                val resInfoList = context.packageManager.queryIntentActivities(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
                for (resolveInfo in resInfoList) {
                    val packageName = resolveInfo.activityInfo.packageName
                    context.grantUriPermission(packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }

                // Try direct WhatsApp if phone or app available
                if (cleanDigits.isNotBlank()) {
                    try {
                        val waIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "image/png"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            putExtra("jid", "$cleanDigits@s.whatsapp.net")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            `package` = "com.whatsapp"
                        }
                        context.startActivity(waIntent)
                        return@runOnUiThread
                    } catch (e: Exception) {
                        // Continue to general WA share or chooser
                    }
                }

                try {
                    val waIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        `package` = "com.whatsapp"
                    }
                    context.startActivity(waIntent)
                } catch (e: Exception) {
                    val chooser = Intent.createChooser(intent, "إرسال صورة الفاتورة عبر واتساب").apply {
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(chooser)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
